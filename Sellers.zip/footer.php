<?php 
$output->footer();
?>