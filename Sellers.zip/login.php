<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>ULTIMO Admin Dashboard Template</title>
<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<link href="css/font-awesome.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="css/animate.css" rel="stylesheet" type="text/css" />
<link href="css/style.css" rel="stylesheet" type="text/css" />



</head>
<body class="light_theme  fixed_header left_nav_fixed" style="background: #262a33;">
<script>
	function login()
			{
				var	username			=	$("#inputEmail3").val();
				var	password			=	$("#inputPassword3").val();
		
				if (window.XMLHttpRequest) {
			            // code for IE7+, Firefox, Chrome, Opera, Safari
			            nxmlhttp = new XMLHttpRequest();
			          
			        } else {
			            // code for IE6, IE5
			            nxmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
			           
			        }
			        
			        nxmlhttp.onreadystatechange = function() {
			            if (nxmlhttp.readyState == 4 && nxmlhttp.status == 200) {
			            	if(nxmlhttp.responseText=="Success")
			            		{
			            			location.assign("index.php");
			            		}
			            	else
			            	{
			            		window.alert(nxmlhttp.responseText);
			            	}
			            	
			            }
			        }
			        
			        nxmlhttp.open("GET","logincontroller.php?submit=Login&&username="+username+"&&password="+password,true);
			        nxmlhttp.send();

		}		
</script>
<div class="wrapper">
  <!--\\\\\\\ wrapper Start \\\\\\-->
  
  
  
  
  
  <div class="login_page">
  <div class="login_content">
  <div class="panel-heading border login_heading">تسجيل الدخول</div>	
 <form role="form" class="form-horizontal" onsubmit="return false;">
      <div class="form-group">
        
        <div class="col-sm-10">
          <input type="text" placeholder="اسم المستخدم" dir="rtl" id="inputEmail3" class="form-control">
        </div>
      </div>
      <div class="form-group">
        
        <div class="col-sm-10">
          <input type="password" placeholder="كلمة المرور" dir="rtl" id="inputPassword3" class="form-control">
        </div>
      </div>
      <div class="form-group">
        <div class=" col-sm-10">
          <div class="checkbox checkbox_margin">
              <button class="btn btn-default pull-right" id="submit" onclick="login()">تسجيل الدخول</button>
              </a></div>
        </div>
      </div>
      
    </form>
 </div>
  </div>
  
  
  
  
  
  
  
  
</div>
<!--\\\\\\\ wrapper end\\\\\\-->
<!-- Modal -->





<script src="js/jquery-2.1.0.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
