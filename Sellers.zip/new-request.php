<?php
require 'header.php';
require 'nav.php';
$output->new_request();


require 'footer.php';
?>
