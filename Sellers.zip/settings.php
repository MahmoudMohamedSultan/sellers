<?php
require 'header.php';
require 'nav.php';
?>
    	
    	
<?php

require 'footer.php';
?>
