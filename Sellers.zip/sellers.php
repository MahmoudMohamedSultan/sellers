<?php
require 'header.php';
require 'nav.php';
$output->sellers();

require 'footer.php';
?>
