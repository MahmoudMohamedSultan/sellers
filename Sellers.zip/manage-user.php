<?php
require 'header.php';
require 'nav.php';
$output->manage_user();


require 'footer.php';
?>
