<?php
require 'header.php';
require 'nav.php';

$output->requests();
    	


require 'footer.php';
?>
