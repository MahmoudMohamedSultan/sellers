<?php
require 'header.php';
require 'nav.php';
$output->home();


require 'footer.php';
?>

