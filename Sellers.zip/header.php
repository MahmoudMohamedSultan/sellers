<?php
session_start();
	if (!isset($_SESSION['id']))
	{
		//die();
		//session_destroy();
		header("Location:login.php");
	}
require 'include/output.php';
$output		=	new Output($_SESSION['id']);
$output->header();

?>
