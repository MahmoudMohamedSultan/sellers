<?php

	if($_GET)
	{
		if(isset($_GET['submit']) AND $_GET['submit']== 'Login')
		{
			$username	= $_GET['username'];
			$passwors	= $_GET['password'];
			try
			{
				include  'include/login.php';
				
				$login	= new login($username,$passwors);
				
				if($login==TRUE)
				{
					$select_id				=	mysql_query("select id from users where username='$username' ");
					$id						=	"";
					while($fetch=mysql_fetch_assoc($select_id))
						$id	=	$fetch['id'];
					session_start();
					$_SESSION['id']	= $id;
					echo "Success";
				}
			}
			catch(exception $exe)
			{
				echo $exe->getMessage();
			}
		}
	}
?>