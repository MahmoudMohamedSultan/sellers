<?php



$connect	=	new Database("localhost","root","root","sellers");

class Database{
private 	$hostname;
private	$username	;
private	$password;
private	$database;
	
	function __construct($host,$user,$pass,$datab)
		{
			$this->hostname		=	$host;
			$this->username		=	$user;
			$this->password		=	$pass;
			$this->database		=	$datab;
			
			$this->connect();
		}

	private function connect()
		{
			if(!mysql_connect($this->hostname,$this->username,$this->password))
				throw new Exception("Error connecting to server");
			if(!mysql_select_db($this->database))
				throw new Exception("Error connecting to database");
	
		}
	
	function close()
	{
		mysql_close();
	}
}

?>