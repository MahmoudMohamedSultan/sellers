<?php
class Output
{
	public $user_type	=	0;
	public $userid		=	0;
	public function __construct($user_id)
	{
		require 'config.php';
		require 'include/functions.php';
		error_reporting(0);
		
		$this->user_type		=	get_sitem('users','type',$user_id);
		$this->userid			=	$user_id;
	}
	public function header()
	{

		
		echo "<!DOCTYPE html>
			<html lang='ar'>
			  <head>
			    <meta charset='utf-8'>
			    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
			    <meta name='viewport' content='width=device-width, initial-scale=1'>
			    <meta name='description' content=''>
			    <meta name='author' content='Mahmoud Sultan'>
			    <link rel='icon' href='../../favicon.ico'>
			
			    <title>TEAM WORK ADSL</title>
			
			    <!-- Bootstrap core CSS -->
			    <link href='css/bootstrap.min.css' rel='stylesheet'>
				<link href='css/style.css' rel='stylesheet'>
				<link href='css/bootstrap.css' rel='stylesheet'>
				<link href='css/font-awesome.css' rel='stylesheet'>
			    <script src='js/jquery-2.1.0.js'></script>
			  </head>
			  <body>
			
			  	<div class='container'>
			  	<div class='row'>
					  		<div class='col-sm-2'>
					  			<a href=''><img src='nlogo.png' height='100' width='200' /></a>
					  		</div>
					  		<div class='col-sm-6'></div>
					  		<div class='col-sm-1'  style='float:right;'></div>
					  		<div class='col-sm-2' style='float:right;'>
					  		<h4>hello <a href='manage-user.php?edit-user&&id=".$this->userid."'>".get_sitem('users','username',$this->userid)."</a></h4>
					  		</div>
					  		
			  	</div>
			    <div class='row'>
			    	";
	}
	
	public function nav()
	{
		echo "
		        <div class='col-md-3 column margintop20'>
		    		<ul class='nav nav-pills nav-stacked'>
		  <li><a href='index.php'>Home</a></li>
		  <li><a href='requests.php'>Requests</a></li>
		  <li><a href='new-request.php' >New ADSL Request</a></li>";
  		if($this->user_type==1)
		{
				echo "<li><a href='sellers.php'>Sellers</a></li>
			  <li><a href='managers.php'>Managers</a></li>
			  <li><a href='settings.php'>Settings</a></li>
			</ul>
			</div> 
			<div class='col-md-9 column margintop20'>";
		}
	}
	
	public function home()
	{
		echo "<div class='home'>
	<div class='row'>
		<div class='col-sm-5'>
			<h4>New Requests</h4>
			<hr />
					 	<table class='table'>
					    <thead>
					      <tr>
					      	<th>#</th>
					        <th>ID</th>
					        <th>Status</th>
					        <th>Seller Name</th>
					        <th>Date</th>
					      </tr>
					    </thead>
					    <tbody>
						";
						new_requests($this->userid);
					 echo"</tbody>
					  </table>
					 
		</div>
		
		<div class='col-sm-2'></div>
		
		<div class='col-sm-6'>
			<h4>Requests Number</h4>
			<hr />
					 	<table class='table' >
					    <thead>
					      <tr>
					      	<th>#</th>
					        <th>Pending</th>
					        <th>Pending installation</th>
					        <th>Completed</th>
					        <th>Suspend</th>
					        <th>Rejected</th>
					      </tr>
					    </thead>
					    <tbody>
					    	
						"; 
						statistics($this->userid);
					echo"</tbody>
					  </table>
					 
		</div>
	</div>
</div>";
	}

	public function sellers()
	{
		if($this->user_type==1)
		{
			echo "<div class='form-group gnew-seller'>
				<a href='manage-user.php' class='btn btn-success'>Add New Neller</a>
			</div>   	
			 <div class='row'>
			 	<h3 class='semi-bold'>Sellers</h3>
			 	<table class='table' >
			    <thead>
			      <tr>
			      	<th>#</th>
			        <th>Seller Name</th>
			        <th>Username</th>
			        <th>Email</th>
			        <th>Edit / Remove</th>
			      </tr>
			    </thead>
			    <tbody>
				";
				display_users(2);
			    echo "</tbody>
			  </table>
			 </div>    ";
		}
		else
		{
			header("Location:index.php");	
		}
	}
	
	public function managers()
	{
		if($this->user_type==1)
		{
			echo "<div class='form-group gnew-seller'>
						<a href='manage-user.php' class='btn btn-success'>Add New Manager</a>
					</div>   	
					 <div class='row managers'>
					 	<h3>Managers</h3>
					 	<table class='table' >
					    <thead>
					      <tr>
					      	<th>#</th>
					        <th>Manager Name</th>
					        <th>Username</th>
					        <th>Email</th>
					        <th>Edit/Remove</th>
			
					      </tr>
					    </thead>
					    <tbody>";
				display_users(1);
				echo "</tbody>
					  </table>
					 </div>   	";
	 	}
		else
		{
			header("Location:index.php");
		}
	}
	
	public function requests()
	{
		echo "<script>
				    function search()
						{
							user_id				=	$('#user').val();
							re_number		=	$('#request-number').val();
							mobile				=	$('#mobile').val();
							start_date			=	$('#start-date').val();
							end_date			=	$('#end-date').val();
							request_status	=	$('#request-status').val();
						 
						        if (window.XMLHttpRequest) {
						            // code for IE7+, Firefox, Chrome, Opera, Safari
						            xmlhttp = new XMLHttpRequest();
						           
						        } else {
						            // code for IE6, IE5
						            xmlhttp = new ActiveXObject('Microsoft.XMLHTTP');
						           
						        }
						        xmlhttp.onreadystatechange = function() {
						            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
						           		document.getElementById('result').innerHTML=xmlhttp.responseText;
						            	
						            	
						            }
						        }
						        
						        xmlhttp.open('GET','include/db.php?search='+user_id+'&&request-number='+re_number+'&&mobile='+mobile+'&&start-date='+start_date+'&&end-date='+end_date+'&&request-status='+request_status,true);
						       
						        xmlhttp.send();
				   
						}
				</script>
					<h3>Search</h3>
				<div class='row search'>
					<form role='form' onsubmit='return false;'>
							<input type='text' id='user' value='".$_SESSION['id']."' style='display: none' />
				
							<div class='col-md-2'></div>
							<div class='col-md-8'>
									<div class='row'>
										<div class='col-sm-5'>
											<div class='form-group'>
												<label for='request-number'>ID</label>
												<input type='text' id='request-number' class='form-control' />
											</div>
										</div>
										
										<div class='col-sm-2'></div>	
										
										<div class='col-sm-5'>
											<div class='form-group'>
												<label for='mobile'>Mobile</label>
												<input type='text' id='mobile' class='form-control' />
											</div>
										</div>
									</div>
									
									<div class='row'>
										<div class='col-sm-5'>
											<div class='form-group'>
												<label for='start-date'>From Date</label>
												<input type='date' id='start-date' class='form-control' />
											</div>
										</div>
										
										<div class='col-sm-2'></div>	
										
										<div class='col-sm-5'>
											<div class='form-group'>
												<label for='end-date'>To Date</label>
												<input type='date' id='end-date' class='form-control' />
											</div>
										</div>
									</div>
									
									<div class='row'>
										<div class='col-sm-5'>
											<div class='form-group'>
												<label for='request-status'>Request Type</label>
												<select id='request-status' class='form-control'>
													<option></option>
													<option value='Pending'>Pending</option>
													<option value='Pending installation'>Pending installation</option>
													<option value='Completed'>Completed</option>
													<option value='Suspend'>Suspend</option>
													<option value='Rejected'></option>`
												</select>
											</div>
										</div>
										
										<div class='col-sm-2'></div>	
										
										<div class='col-sm-5'>
											<div class='form-group'>
												<button class='btn btn-success' onclick='search()'>Search</button>
											</div>
										</div>
									</div>
							</div>
							<div class='col-md-2'></div>
					</form>
				</div>
				<div class='row' id='result'>
					
				</div>    	";
	}
	
	public function request_info()
	{
		$re_id				=	0;
		$customer_id		=	0;
		if(isset($_GET['re-id']))
		{
			$re_id				=	$_GET['re-id'];
			$customer_id		=	get_sitem('adslrequests','customerid',$re_id);
			if($this->user_type!=1&&$_SESSION['id']!=get_sitem('adslrequests','userrid',$re_id))
				header("Location:index.php");
		}
		
		echo "<div class='re-info'>
					<h4>Request Info</h4>
					<hr />
					<div class='row'>
						<div class='col-sm-4'>
							<label>Telephone Owner Name :         </label> <label>".get_sitem('adslrequests','telownername',$re_id)."</label>
						</div>
						<div class='col-sm-4'>
							<label>Telephone Number :         </label> <label>".get_sitem('adslrequests','telephone',$re_id)."</label>
						</div>
						<div class='col-sm-4'>
							<label>Address :         </label> <label>".get_sitem('adslrequests','address',$re_id)."</label>
						</div>
					</div>
					
					<div class='row'>
						<div class='col-sm-4'>
							<label>Speed :         </label> <label>".get_sitem('settings','property',get_sitem('adslrequests','speed_id',$re_id))."</label>
						</div>
						";
						if($this->user_type==1)
						{
						echo "	<div class='col-sm-3'>
								<form action='include/db.php?re-id=".$re_id."' method='post'>
									<div class='form-group'>
											<label>Request Type :         </label> 
											<select name='request-status' class='form-control'>
												<option value='Pending'"; if(get_sitem('adslrequests','requeststatuse',$re_id)=='Pending') echo 'Selected'; echo ">Pending</option>
												<option value='Pending installation'"; if(get_sitem('adslrequests','requeststatuse',$re_id)=='Pending installation') echo 'Selected'; echo ">Pending installation</option>
												<option value='Completed'"; if(get_sitem('adslrequests','requeststatuse',$re_id)=='Completed') echo 'Selected'; echo ">Completed</option>
												<option value='Suspend'"; if(get_sitem('adslrequests','requeststatuse',$re_id)=='Suspend') echo 'Selected'; echo ">Suspend</option>
												<option value='Rejected'"; if(get_sitem('adslrequests','requeststatuse',$re_id)=='Rejected') echo 'Selected'; echo "></option>`
											</select>
									</div>
									<div class='form-group'>
										<input type='submit' class='btn btn-success' name='ch-status' />
									</div> 
								</form>
							</div>";
						}
				echo"	</div>
					
					
				</div>
				
				<div class='re-info'>
					<h4>Request Info</h4>
					<hr />
					<div class='row'>
						<div class='col-sm-4'>
							<label>Customer Name :         </label> <label>". get_sitem('customers','name',$customer_id)."</label>
						</div>
						<div class='col-sm-4'>
							<label>Mobile :         </label> <label>".get_sitem('customers','mobile',$customer_id)."</label>
						</div>
						<div class='col-sm-4'>
							<label>ID Card Number :         </label> <label>".get_sitem('customers','idcardnumber',$customer_id)."</label>
						</div>
					</div>
						
				</div>
				
				<div class='re-info'>
					<h4>Attachments</h4>
					<hr />
					<div class='row'>
						<div class='col-sm-2'>
							<a href='".get_sitem('attachments','url',get_sitem('adslrequests','contructimage_id',$re_id))."' >Contruct</a>
						</div>
						<div class='col-sm-2'>
							<a href='".get_sitem('attachments','url',get_sitem('adslrequests','telbillimage_id',$re_id))."' >Telephone Bill</a>
						</div>
						<div class='col-sm-2'>
							<a href='".get_sitem('attachments','url',get_sitem('adslrequests','payment_id',$re_id))."' >Check Payment</a>
						</div>
						<div class='col-sm-2'>
							<a href='".get_sitem('attachments','url',get_sitem('customers','idfrontimage',$customer_id))."' >ID Image (Front)</a>
						</div>
						<div class='col-sm-2'>
							<a href='".get_sitem('attachments','url',get_sitem('customers','idbackimage',$customer_id))."' >ID Image (Back)</a>
						</div>
					</div>
						
				</div>";
	}
	
	public function new_request()
	{
		echo "<script>

			$(document).ready(function (e) {
				$('#reform').on('submit',(function(e) {
					e.preventDefault();
					$.ajax({
			        	url: 'include/db.php',
						type: 'POST',
						data:  new FormData(this),
						contentType: false,
			    	    cache: false,
						processData:false,
						success: function(data)
					    {
							window.alert(data);
					    }        
				   });
				}));
			});
			
			
			</script>
			<div class='row'>
				<h3>New Request</h3>
				<form id='reform' action='include/db.php' method='post'  enctype='multipart/form-data'>
					<input type='text' name='newrequest' value='".$_SESSION['id']."' style='display: none' />
					<div class='customer-info'>
						<h4>Request Info</h4>
						<hr />
						<div class='row'>
							<div class='col-sm-4'>
								<div class='form-group'>
									<label for='customer-name'>Customer Info :</label>
									<input type='text' class='form-control' name='customer-name' />
								</div>
							</div>
							
							<div class='col-sm-4'>
								<div class='form-group'>
									<label for='mobile'>Mobile :</label>
									<input type='text' class='form-control' name='mobile' />
								</div>
							</div>
							
							<div class='col-sm-4'>
								<div class='form-group'>
									<label for='idcardnumber'>ID Card Number :</label>
									<input type='text' class='form-control' name='idcardnumber' />
								</div>
							</div>
						</div>
						
						<div class='row'>
							<div class='col-sm-4'>
								<div class='form-group'>
									<label for='idfrontimage'>ID Image (Front) :</label>
									<input type='file' name='idfrontimage' class='form-control' />
								</div>
							</div>
							
					 		<div class='col-sm-4'>
								<div class='form-group'>
									<label for='idbackimage'>ID Image (Back) :</label>
									<input type='file' name='idbackimage' class='form-control' />
								</div>
							</div>
							
											
						</div>
					</div>
					
					<div class='request-info'>
						<h4>Line Info</h4>
						<hr />
						<div class='row'>
							
							<div class='col-sm-4'>
								<div class='form-group'>
									<label for='teloname'>Telephone Owner Name :</label>
									<input type='text' class='form-control' name='teloname' />
								</div>
							</div>
							
							<div class='col-sm-4'>
								<div class='form-group'>
									<label for='telephone'>Telephone Number :</label>
									<input type='text' class='form-control' name='telephone' />
								</div>
							</div>	
						
							<div class='col-sm-4'>
								<div class='form-group'>
									<label for='address'>Address :</label>
									<input type='text' class='form-control' name='address' />
								</div>
							</div>		
						</div>
						
						<div class='row'>
							<div class='col-sm-3'>
								<div class='form-group'>
									<label for='speed'>Speed :</label>
									<select class='form-control' name='speed'>
										";
										add_to_list('settings','property',"cat='speed'");
							echo "</select>
								</div>
							</div>
							
							<div class='col-sm-3'>
								<div class='form-group'>
									<label for='billimage'>Telephone Bill Image :</label>
									<input type='file' class='form-control' name='billimage' /> 
								</div>
							</div>	
			
							<div class='col-sm-3'>
								<div class='form-group'>
									<label for='contructimage'>Contruct Image :</label>
									<input type='file' class='form-control' name='contructimage' /> 
								</div>
							</div>	
							
							<div class='col-sm-3'>
								<div class='form-group'>
									<label for='payment'>Check Payment Image :</label>
									<input type='file' class='form-control' name='payment' /> 
								</div>
							</div>						
						</div>				
					</div>
				<div class='row'>
					<div class='col-sm-4'></div>
					<div class='col-sm-1'></div>
					<div class='col-sm-2'>
						<div class='form-group'>
							<input id='button' class='btn btn-success' type='submit' value='Send Request'>
							<!--<button class='btn btn-success' id='sendrequest' onclick='newrequest(".$_SESSION['id'].")'></button>-->
						</div>
					</div>
					<div class='col-sm-1'></div>
					<div class='col-sm-4'></div>
				</div>	
			 </form>
			</div>    	";
	}
	
	public function manage_user()
	{
		$action			=	"";
		$get_name	=	"new-user";
		$id			=	0;
		if(isset($_GET['edit-user']))
		{
			$id					=	$_GET['id'];
			
			if($this->user_type!=1&&$id!=$_SESSION['id'])
				header("Location:index.php");
			//$action			=	"?edit-user&&id=".$id;
			$get_name	=	"edit-user";
		}
		
		echo "<script>
			function saveuser()
					{
						var	id						=	$('#id').val();
						var	request_name	=	$('#getname').val();
						var	name					=	$('#name').val();
						var	email				=	$('#email').val();
						var	mobile				=	$('#mobile').val();
						var	username			=	$('#username').val();
						var	password			=	$('#password').val();
						var	type					=	$('#type').val();
				
						if (window.XMLHttpRequest) {
					            // code for IE7+, Firefox, Chrome, Opera, Safari
					            nxmlhttp = new XMLHttpRequest();
					          
					        } else {
					            // code for IE6, IE5
					            nxmlhttp = new ActiveXObject('Microsoft.XMLHTTP');
					           
					        }
					        
					        nxmlhttp.onreadystatechange = function() {
					            if (nxmlhttp.readyState == 4 && nxmlhttp.status == 200) {
					            window.alert(nxmlhttp.responseText);
					            	
					            }
					        }
					        
					        nxmlhttp.open('GET','include/db.php?manage-user&&'+request_name+'&&id='+id+'&&name='+name+'&&email='+email+'&&mobile='+mobile+'&&username='+username+'&&password='+password+'&&type='+type,true);
					        nxmlhttp.send();
		
				}		
		</script>
		<div class='row manage_user' dir='rtl'>
			<h3>Add New User</h3>
			<form  role='form' onsubmit='return false;'>	
				<input type='text' id='id' value='".$id."' style='display: none;' />
				<input type='text' id='getname' value='".$get_name."' style='display: none;' />
				<div class='row'>
					<div class='col-md-2'>
						<div class='form-group'>
							<label for='type'>User Type :</label>
							<select class='form-control'  id='type' >
								<option value='2'"; if(get_sitem('users','type',$id)==2) echo 'Selected'; echo ">Seller</option>
								<option value='1'"; if(get_sitem('users','type',$id)==1) echo 'Selected'; echo ">Manager</option>
							</select>
						</div>
					</div>
					
					<div class='col-md-4'>	
						<div class='form-group'>
									<label for='name'>Name :</label>
									<input type='text' class='form-control' value='".get_sitem('users','name',$id)."' id='name' />
						</div>
					</div>
					
					<div class='col-md-3'>	
						<div class='form-group'>
									<label for='email'>Email :</label>
									<input type='email' class='form-control' value='".get_sitem('users','email',$id)."' id='email' />
						</div>
					</div>
					<div class='col-md-3'>	
						<div class='form-group'>
									<label for='mobile'>Mobile :</label>
									<input type='text' class='form-control' value='".get_sitem('users','mobile',$id)."' id='mobile' />
						</div>
					</div>

				</div>
				<div class='row'>
					
					<div class='col-md-4'>
						<div class='form-group'>
							<label for='username'>Username :</label>
							<input type='text' class='form-control' value='".get_sitem('users','username',$id)."' id='username' />
						</div>
					</div>
					
					<div class='col-md-4'>
						<div class='form-group'>
							<label for='password'>Password :</label>
							<input type='password' class='form-control' value='' id='password' />
					</div>
					
					</div>
					
					<div class='col-md-2'>
						<div class='form-group'>
							<button id='save' onclick='saveuser()' class='btn btn-success' >Save</button>
						</div>
					</div>
					<div class='col-md-2'>
						
					</div>
					

					
					
				</div>
			</form>
		</div> 
		
		<div class='row'>";
			if(isset($_GET['edit-user'])) user_requests($_GET['id']);
		echo "</div>  	
		";
	}

	public function footer()
	{
		echo "    </div></div>
</div>
  </body>
  </html>";
	}
}
?>