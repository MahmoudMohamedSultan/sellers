<?php
mysql_query("SET NAMES 'utf8'");

function display_users($type)
{
	$select		=	mysql_query("select * from users where type=$type");
	$counter	=	1;
	while($fetch=mysql_fetch_array($select))
	{
		$id				=	$fetch['id'];
		$name			=	$fetch['name'];
		$email			=	$fetch['email'];
		$username		=	$fetch['username'];
		
		echo "<tr>
        <td>$counter</td>
        <td>$name</td>
        <td>$username</td>
        <td>$email</td>
        <td>
        <a href='manage-user.php?edit-user&&id=$id'>Edit</a>
        / <a href='include/db.php?remove-user&&id=$id'>Remove</a>
        </td>
        <td><a href='#'>Report</a></td></tr>
        ";
		
		$counter++;
	}
}

function check_item($table,$column,$cond)
{
	$select				=	mysql_query("select * from $table where $column='$cond' ");
	$num_rows		=	mysql_num_rows($select);
	return $num_rows;
}

function get_sitem($tname,$require,$id)
{
	$select	=	mysql_query("select $require from $tname where id=$id");
	$output	=	"";
	while($fetch=mysql_fetch_assoc($select))
	{
		$output	=	$fetch[$require];
	}
	return $output;
}

function add_to_list($tname,$column,$cond)
{
	$query		=	"select * from $tname";
	if($cond!="")
	{
		$query	=	$query." where ".$cond;
	}
	
	$query		=	mysql_query($query);
	
	while($fetch=mysql_fetch_array($query))
	{
		$id			=	$fetch['id'];
		$display	=	$fetch[$column];
		
		echo "<option value='$id'>$display</option>";
	}
	
}

function user_requests($user_id)
{
	$query		=	mysql_query("select * from adslrequests where userrid=$user_id");
	
	echo "<table class='table' dir='rtl'>
    <thead>
      <tr>
      	<th>#</th>
        <th>ID</th>
        <th>Request Date</th>
        <th>Request Sender</th>
        <th>Request Type</th>
      </tr>
    </thead>
    <tbody>";
	
		$counter	=	1;
		while($fetch=mysql_fetch_array($query))
		{
			$r_user			=	$fetch['userrid'];
			$r_id				=	$fetch['id'];
			$r_date			=	$fetch['requestdate'];
			$r_status		=	$fetch['requeststatuse'];
			$user_name	=	get_sitem('users','username',$r_user);
			echo "<tr>
        	<td>$counter</td>
        	<td>$r_id</td>
       		<td>$r_date</td>
        	<td>$user_name</td>
       		<td>$r_status</td>
			</tr>";
		
			$counter ++;
		}
		
		echo "</tbody>
  </table>";
}
function counter($user_id,$required)
{
	$query				=	"select * from adslrequests";
	if($required!=' ')
	{
		$query			=	$query." where requeststatuse='$required'";
	}
	$user_type		=	get_sitem('users','type',$user_id);
	if($user_type!=1)
	{
		if($required!=' ')
		{
			$query	=	$query." &&";
		}
		else
		{
			$query	=	$query." where";
		}
		$query		=	$query." userrid=$user_id";
	}
	$query			=	mysql_query($query);
	$count			=	mysql_num_rows($query);
	return $count;
}

function statistics($user_id)
{
	$all								=	counter($user_id,' ');
	$pending						=	counter($user_id,'Pending');
	$pending_installation		=	counter($user_id,'Pending installation');
	$completed					=	counter($user_id,'Completed');
	$suspend						=	counter($user_id,'Suspend');
	$rejected						=	counter($user_id,'Rejected');
	
	echo "<tr>
        	<td>$all</td>
        	<td>$pending</td>
       		<td>$pending_installation</td>
        	<td>$completed</td>
       		<td>$suspend</td>
       		<td>$rejected</td>
			</tr>";
}

function new_requests($user_id)
{
	$query			=	"select * from adslrequests";
	$user_type		=	get_sitem('users','type',$user_id);
	if($user_type!=1)
	{
		$query		=	$query." where userrid=$user_id";
	}
	$query			=	$query." ORDER BY id DESC";
	$query			=	mysql_query($query);
	$counter		=	1;
	while($fetch=mysql_fetch_array($query))
	{
		$id						=	$fetch['id'];
		$status					=	$fetch['requeststatuse'];
		$user_id				=	$fetch['userrid'];	
		$date						=	$fetch['requestdate'];
		$user_name			=	get_sitem('users','username',$user_id);
		echo "<tr>
        	<td>$counter</td>
        	<td><a href='request-info.php?re-id=$id'>$id</a></td>
       		<td>$status</td>
        	<td>$user_name</td>
       		<td>$date</td>
			</tr>";
		$counter++;
		
		if($counter>5)
		break;
	}
}


function upload_image(array $image_sc)
{
		$target_dir = "../attachments/";
		$img_name	=	basename($image_sc["name"]);
		$target_file = $target_dir .basename($image_sc["name"]);
		$uploadOk = 1;
		$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

		// Check if image file is a actual image or fake image
		$check = getimagesize($image_sc["tmp_name"]);
		    if($check !== false) {
		        //echo "File is an image - " . $check["mime"] . ".";
		        $uploadOk = 1;
		    } else {
		        echo "File is not an image.";
		        $uploadOk = 0;
		    }
		
		// Check if file already exists
		if (file_exists($target_file)) {
		    echo "Sorry ,  $img_name already exist";
		    $uploadOk = 0;
		} 
		
				// Check file size
/*	if ($_FILES["upload-image"]["size"] > 1000000) {
		    echo "Sorry, your file is too large.";
		    $uploadOk = 0;
		}
 
*/
		// Allow certain file formats
		if($imageFileType != "JPG" && $imageFileType != "png" && $imageFileType != "jpeg"
		&& $imageFileType != "gif" && $imageFileType != "jpg" ) {
		    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
		    $uploadOk = 0;
		}
		// Check if $uploadOk is set to 0 by an error
		if ($uploadOk == 0) {
		    echo "Sorry, your file was not uploaded.";
		// if everything is ok, try to upload file
		} else {
		    if (move_uploaded_file($image_sc["tmp_name"], $target_file)) {
		        echo "The file ". basename($image_sc["name"]). " Attachment Success.";
						$target_file	=	"attachments/".$img_name;
						mysql_query("insert into attachments(url) values(n'$target_file')");
						$id				=	mysql_insert_id();
						return $id;
		    } else {
		        echo "F";
		    }
		}
		//$target_file	=	"attachments/".$img_name;
		//mysql_query("insert into images(name,url) values(n'$img_name',n'$target_file')");
}

?>