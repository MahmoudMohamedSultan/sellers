<?php
	
	/**
	 * 
	 */
	class login 
		{
			private	$username;
			private $password;
			private $cnx;
			
		function __construct($username, $password) 
		{
			//set data
			$this->setdata($username, $password);
			//connect to database
			$this->connectdata();
			//get data
			$this->getdata();
		}
		private function setdata($username,$password)
		{
			$this->username	=	$username;
			$this->password	=	md5($password);
		}
		private function connectdata()
		{
			include 	'config.php';
		}
		private function getdata()
		{
			$query	=	"SELECT * FROM users WHERE username='$this->username' AND password='$this->password'";
			$sql	=	mysql_query($query);
			
			if(mysql_num_rows($sql) > 0 )
			{
				return TRUE;
			}
			else
				{
					throw new Exception("username or password is not invalid");
				} 
			
		}
		function close()
		{
			$this->cnx->close();
		}
	}
	



?>