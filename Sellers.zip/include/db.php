<?php
require '../config.php';
require 'functions.php';
if(isset($_GET['manage-user']))
{
	$type				=	$_GET['type'];
	$name			=	$_GET['name'];
	$email			=	$_GET['email'];
	$mobile			=	$_GET['mobile'];
	$username		=	$_GET['username'];
	$password		=	$_GET['password'];
	$p_cond		=	"";
	if($password!="")
	{
		$password		=	 md5($password);
		$p_cond	=	",password='".$password."'";
	}
	
	if(isset($_GET['edit-user']))
	{
		$id			=	$_GET['id'];
		
		
		
		if(check_item('users','username',$username)>0&&get_sitem('users','username',$id)!=$username)
		{
			
			echo "Exist Username";
		}
		elseif(check_item('users','email',$email)>0&&get_sitem('users','email',$id)!=$email)
		{
			echo "Exist Email";
		}
		elseif(check_item('users','mobile',$mobile)>0&&get_sitem('users','mobile',$id)!=$mobile)
		{
			echo "Exist Mobile";
		}
		else
		{
			if(mysql_query("update users set name=n'$name',email='$email',mobile='$mobile',username=n'$username'$p_cond,type=$type where id=$id "))
			{
				echo "Editing User Success";
			}
		}
	}
	else 
	{
		if(check_item('users','username',$username)>0)
		{
			
			echo "Exist Username";
		}
		elseif(check_item('users','email',$email)>0)
		{
			echo "Exist Email";
		}
		elseif(check_item('users','mobile',$mobile)>0)
		{
			echo "Exist Mobile";
		}
		else
		{
			if(mysql_query("insert into users(name,mobile,email,username,password,type) values(n'$name','$mobile','$email',n'$username','$password',$type)"))
				{
				echo "Adding User Success";
				}
		}
	
	}
}

if(isset($_POST['newrequest']))
{
	
	$user_id					=	$_POST['newrequest'];
	$customer_name		=	$_POST['customer-name'];
	$mobile						=	$_POST['mobile'];
	$idcard_number		=	$_POST['idcardnumber'];
	$telo_name				=	$_POST['teloname'];
	$telephone					=	$_POST['telephone'];
	$address					=	$_POST['address'];
	$speed						=	$_POST['speed'];
	
	if(check_item('customers','idcardnumber',$idcard_number)>0)
	{
		echo "Exist ID Number";
	}
	elseif(check_item('customers','mobile',$mobile)>0)
	{
		echo "Exist Number";
	}
	elseif(check_item('adslrequests','telephone',$telephone)>0)
	{
		echo "Exist Telephone";
	}
	else
	{
		$frontcard_id				=	upload_image($_FILES['idfrontimage']);
		$backcard_id				=	upload_image($_FILES['idbackimage']);
		$billimage_id				=	upload_image($_FILES['billimage']);
		$contructimage_id		=	upload_image($_FILES['contructimage']);
		$payment_id				=	upload_image($_FILES['payment']);
		
		if(check_item('attachments','id',$frontcard_id)>0&&check_item('attachments','id',$backcard_id)>0&&check_item('attachments','id',$billimage_id)>0&&check_item('attachments','id',$contructimage_id)>0&&check_item('attachments','id',$payment_id)>0)
		{
			
			$insert_customer	=	mysql_query("insert into customers(name,mobile,idcardnumber,idfrontimage,idbackimage,userid) values(n'$customer_name','$mobile','$idcard_number',$frontcard_id,$backcard_id,$user_id)");
			$customer_id			=	mysql_insert_id();
			if($insert_customer)
			{
				$insert_request	=	mysql_query("insert into adslrequests(customerid,telownername,telephone,address,speed_id,telbillimage_id,contructimage_id,payment_id,userrid) values($customer_id,n'$telo_name','$telephone',n'$address',$speed,$billimage_id,$contructimage_id,$payment_id,$user_id)");
				$request_id		=	mysql_insert_id();
				
				if($insert_request)
				{
					echo "Sending Request Success AND Request ID is   $request_id";
				}
				else {
					{
						echo "Sorry , Failed Sending Request";
					}
				}
			}
		}
	}
}
if(isset($_GET['remove-user']))
{
	$user_id		=	$_GET['id'];
	$user_type		=	get_sitem('users','type',$user_id);
	mysql_query("delete from users where id=$user_id");
	if($user_type==1)
	{
		header('Location:../managers.php');
	}
	else
	{
		header('Location:../sellers.php');
	}
}

if(isset($_GET['search']))
{
	$user_id				=	$_GET['search'];
	$request_id			=	$_GET['request-number'];
	$mobile					=	$_GET['mobile'];
	$start_date			=	$_GET['start-date'];
	$end_date				=	$_GET['end-date'];
	$request_status		=	$_GET['request-status'];
	
	$cond					=	"where ";
	$cond_status			=	0;
	if($request_id!="")
	{
		$cond				=	$cond."id=$request_id ";
		$cond_status		=	1;
	}
	elseif($mobile!="")
	{
		$gcustomer_q	=	mysql_query("select id from customers where mobile='$mobile' ");
		$customer_id		=	0;
		while($fetch_id=mysql_fetch_assoc($gcustomer_q))
		{
			$customer_id		=	$fetch_id['id'];	
		}
		if($customer_id!=0)
		{
			$cond				=	$cond."customerid=$customer_id ";
			$cond_status		=	1;
		}
	}
	else
	{
			if($start_date!="")
			{
				$cond			=	$cond."requestdate>='$start_date' ";
				$cond_status	=	1;
			}
			
			if($end_date!="")
			{
				if($cond_status==1)
				{
					$cond			=	$cond."and requestdate<='$end_date' ";
				}
				else
				{
					$cond			=	$cond."requestdate<='$end_date' ";
					$cond_status	=	1;	
				}
			}
			
			if($request_status!="")
			{
				if($cond_status==1)
				{
					$cond			=	$cond."and requeststatuse='$request_status' ";
				}
				else
				{
					$cond			=	$cond."requeststatuse='$request_status' ";	
					$cond_status	=	1;
				}
			}
			
	}
	
	if($cond_status==1)
	{
		$query					=	mysql_query("select * from adslrequests $cond");
		echo "<table class='table' dir='rtl'>
    <thead>
      <tr>
      	<th>#</th>
        <th>Request Number</th>
        <th>Request Date</th>
        <th>Request Sender</th>
        <th>Request Type</th>
      </tr>
    </thead>
    <tbody>";
    	$counter	=	1;
		while($fetch=mysql_fetch_array($query))
		{
			$r_user			=	$fetch['userrid'];
			if($r_user==$user_id||get_sitem('users','type',$user_id)==1)
			{
				$r_id				=	$fetch['id'];
				$r_date			=	$fetch['requestdate'];
				$r_status		=	$fetch['requeststatuse'];
				$user_name	=	get_sitem('users','username',$r_user);
				echo "<tr>
        <td>$counter</td>
        <td><a href='request-info.php?re-id=$r_id'>$r_id</a></td>
        <td>$r_date</td>
        <td>$user_name</td>
        <td>$r_status</td>
		</tr>";
			}
			$counter ++;
		}
		
		echo "</tbody>
  </table>";
	} 
	else
	{
		echo "no cond";	
	}
	

}

if(isset($_POST['ch-status']))
{
	$request_id		=	$_GET['re-id'];
	$status				=	$_POST['request-status'];
	mysql_query("update adslrequests set requeststatuse='$status' where id=$request_id");
	header("Location:../request-info.php?re-id=$request_id");	
}


?>