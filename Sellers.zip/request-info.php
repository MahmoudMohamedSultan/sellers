<?php
require 'header.php';
require 'nav.php';
$output->request_info();


require 'footer.php';
?>