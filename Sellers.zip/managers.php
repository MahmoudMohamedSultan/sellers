<?php
require 'header.php';
require 'nav.php';
$output->managers();


require 'footer.php';
?>
